export enum Layers_enum {
    MENU = "menu",
    BACK = "background",
    TILES = "tiles",
    PAUSE = "pause"
}